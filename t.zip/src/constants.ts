export const apiBaseUrl = 'https://api.publicapis.org';

export const columns = ['API', 'Description', 'Auth', 'HTTPS', 'Cors', 'Link', 'Category', 'Action'];
